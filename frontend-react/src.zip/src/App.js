import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import Create_Campaign from "./components/Create_Campaign";
import Run_Campaign from "./components/Run_Campaign";
import Layout from "./components/Layout";
import Campaign_Summary from "./components/Campaign_Summary";
import Campaign_Dashboard from "./components/Campaign_Dashboard";
import TemplateCreation from "./components/TemplateCreation";

const isAuthenticated = () => !!localStorage.getItem("token");
const PrivateRoute = ({ children }) =>
  isAuthenticated() ? children : <Navigate to="/login" replace />;

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public login page */}
        <Route path="/login" element={<Login />} />

        {/* Protected dashboard */}
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </PrivateRoute>
          }
        />

         {/* Protected Campaign Dashboard page */}
        <Route
          path="/campaign-dashboard"
          element={
            <PrivateRoute>
              <Layout>
                <Campaign_Dashboard />
              </Layout>
            </PrivateRoute>
          }
        />

        {/* Protected Create Campaign page */}
        <Route
          path="/create-campaign"
          element={
            <PrivateRoute>
              <Layout>
                <Create_Campaign />
              </Layout>
            </PrivateRoute>
          }
        />

         {/* Protected Campaign Summary page */}
        <Route
          path="/campaign-summary"
          element={
            <PrivateRoute>
              <Layout>
                <Campaign_Summary />
              </Layout>
            </PrivateRoute>
          }
        />


        {/* Protected Run Campaign page */}
        <Route
          path="/run-campaign"
          element={
            <PrivateRoute>
              <Layout>
                <Run_Campaign />
              </Layout>
            </PrivateRoute>
          }
        />

        {/* Protected Template Creation page */}
        <Route
          path="/template"
          element={
            <PrivateRoute>
              <Layout>
                <TemplateCreation />
              </Layout>
            </PrivateRoute>
          }
        />

        {/* Catch-all routes redirect to login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}
